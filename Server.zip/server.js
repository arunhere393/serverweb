/**
 * ARUN'S SERVER v3.0
 * Railway + Cloudinary Edition
 * Features: Auth, Public Tunnel, Localhost Tunnels, Port Forwarding, File Manager
 */

const express     = require('express');
const cors        = require('cors');
const bcrypt      = require('bcrypt');
const jwt         = require('jsonwebtoken');
const multer      = require('multer');
const path        = require('path');
const fs          = require('fs').promises;
const { v4: uuidv4 } = require('uuid');
const localtunnel = require('localtunnel');
const { spawn }   = require('child_process');
const cloudinary  = require('cloudinary').v2;

const app  = express();
const PORT = process.env.PORT || 3000;

// ── ENV (set all of these in Railway dashboard → Variables) ───────────────
const JWT_SECRET  = process.env.JWT_SECRET            || 'change-me-railway';
const ADMIN_USER  = process.env.ADMIN_USERNAME         || 'Arun';
const ADMIN_PASS  = process.env.ADMIN_PASSWORD         || 'arun123';

cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME || '',
    api_key:    process.env.CLOUDINARY_API_KEY    || '',
    api_secret: process.env.CLOUDINARY_API_SECRET || '',
    secure: true
});

// ── DIRS ──────────────────────────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, 'data');
const TEMP_DIR = path.join(__dirname, 'temp');

(async () => {
    for (const d of [DATA_DIR, TEMP_DIR, path.join(__dirname, 'public')]) {
        await fs.mkdir(d, { recursive: true });
    }
})();

// ── MIDDLEWARE ─────────────────────────────────────────────────────────────
app.use(cors({ origin: '*', methods: ['GET','POST','PUT','DELETE','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
app.options('*', cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ── DB ─────────────────────────────────────────────────────────────────────
const DB = {
    async read(col) {
        try { return JSON.parse(await fs.readFile(path.join(DATA_DIR, `${col}.json`), 'utf8')); }
        catch { return []; }
    },
    async write(col, data) {
        await fs.writeFile(path.join(DATA_DIR, `${col}.json`), JSON.stringify(data, null, 2));
    }
};

// Bootstrap admin
(async () => {
    const users = await DB.read('users');
    if (!users.length) {
        users.push({ id: 1, username: ADMIN_USER, password: await bcrypt.hash(ADMIN_PASS, 10), role: 'admin', createdAt: new Date().toISOString() });
        await DB.write('users', users);
        console.log(`✓ Admin: ${ADMIN_USER} / ${ADMIN_PASS}`);
    }
})();

// ── AUTH MIDDLEWARE ────────────────────────────────────────────────────────
const auth = (req, res, next) => {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'No token' });
    try { req.user = jwt.verify(token, JWT_SECRET); next(); }
    catch { res.status(403).json({ error: 'Invalid token' }); }
};

// ── FILE UPLOAD (temp → Cloudinary) ───────────────────────────────────────
const upload = multer({ dest: TEMP_DIR, limits: { fileSize: 100 * 1024 * 1024 } });

// ══════════════════════════════════════════════════════════════════════════
//  TUNNEL MANAGER
// ══════════════════════════════════════════════════════════════════════════
class TunnelManager {
    constructor() {
        this.pub = new Map();  // userId   → tunnel entry
        this.loc = new Map();  // tunnelId → tunnel entry
    }

    // ── PUBLIC TUNNEL ──────────────────────────────────────────────────
    async startPublic(userId, port, provider = 'localtunnel') {
        await this.stopPublic(userId);

        if (provider === 'localtunnel') {
            const tun = await localtunnel({ port });
            this.pub.set(userId, { tun, url: tun.url, port, provider, startedAt: new Date().toISOString() });
            tun.on('close', () => this.pub.delete(userId));
            tun.on('error', () => this.pub.delete(userId));
            return tun.url;
        }

        const cfg = {
            ngrok:      { bin: 'ngrok',       args: ['http', String(port)],                       re: /https:\/\/[a-z0-9-]+\.ngrok[-a-z.]*/ },
            cloudflare: { bin: 'cloudflared',  args: ['tunnel','--url',`http://localhost:${port}`], re: /https:\/\/[a-z0-9-]+\.trycloudflare\.com/ }
        }[provider];
        if (!cfg) throw new Error('Unknown provider: ' + provider);

        return new Promise((res, rej) => {
            const proc = spawn(cfg.bin, cfg.args);
            let out = '';
            const t = setTimeout(() => { proc.kill(); rej(new Error(cfg.bin + ' timed out')); }, 30000);
            const check = d => { out += d; const m = out.match(cfg.re); if (m) { clearTimeout(t); this.pub.set(userId, { proc, url: m[0], port, provider, startedAt: new Date().toISOString() }); res(m[0]); } };
            proc.stdout.on('data', check); proc.stderr.on('data', check);
            proc.on('error', e => { clearTimeout(t); rej(e); });
            proc.on('exit', c => { if (!this.pub.has(userId)) { clearTimeout(t); rej(new Error(`${cfg.bin} exited (${c})`)); } });
        });
    }

    async stopPublic(userId) {
        const t = this.pub.get(userId);
        if (!t) return false;
        try { if (t.tun?.close) await t.tun.close(); if (t.proc) t.proc.kill('SIGTERM'); } catch {}
        this.pub.delete(userId);
        return true;
    }

    getPublic(userId) { return this.pub.get(userId); }

    // ── LOCALHOST TUNNELS ──────────────────────────────────────────────
    async createLocal(userId, cfg) {
        const { port, provider = 'localtunnel', subdomain, name, requireAuth = false, region, protocol } = cfg;
        const id = uuidv4();
        let url, tun, proc;

        if (provider === 'localtunnel') {
            tun = await localtunnel({ port, subdomain: subdomain || undefined });
            url = tun.url;
            tun.on('close', () => { const e = this.loc.get(id); if (e) e.isActive = false; });
        } else {
            const pcfg = {
                ngrok:      { bin: 'ngrok',       args: ['http', String(port)],                        re: /https:\/\/[a-z0-9-]+\.ngrok[-a-z.]*/ },
                cloudflare: { bin: 'cloudflared',  args: ['tunnel','--url',`http://localhost:${port}`],  re: /https:\/\/[a-z0-9-]+\.trycloudflare\.com/ }
            }[provider];
            if (!pcfg) throw new Error('Unknown provider');
            ({ url, proc } = await new Promise((res, rej) => {
                const p = spawn(pcfg.bin, pcfg.args);
                let out = '';
                const t = setTimeout(() => { p.kill(); rej(new Error(pcfg.bin + ' timed out')); }, 30000);
                const check = d => { out += d; const m = out.match(pcfg.re); if (m) { clearTimeout(t); res({ url: m[0], proc: p }); } };
                p.stdout.on('data', check); p.stderr.on('data', check);
                p.on('error', e => { clearTimeout(t); rej(e); });
                p.on('exit', c => { clearTimeout(t); rej(new Error(`${pcfg.bin} exited (${c})`)); });
            }));
        }

        const entry = { id, userId, port, name: name || `localhost:${port}`, provider, publicUrl: url, subdomain: subdomain || null, region: region || 'auto', protocol: protocol || 'http', requireAuth, isActive: true, createdAt: new Date().toISOString(), tun, proc };
        this.loc.set(id, entry);
        await this._save();
        return { id, publicUrl: url };
    }

    async stopLocal(id) {
        const t = this.loc.get(id);
        if (!t) return false;
        try { if (t.tun?.close) await t.tun.close(); if (t.proc) t.proc.kill('SIGTERM'); } catch {}
        t.isActive = false;
        await this._save();
        return true;
    }

    async deleteLocal(id) {
        await this.stopLocal(id);
        this.loc.delete(id);
        await this._save();
    }

    getLocal(id)          { return this.loc.get(id); }
    getUserLocals(userId) { return [...this.loc.values()].filter(t => t.userId === userId); }
    clean(t)              { const { tun, proc, ...r } = t; return r; }

    async _save() {
        await DB.write('localTunnels', [...this.loc.values()].map(t => this.clean(t)));
    }

    async loadMeta() {
        const saved = await DB.read('localTunnels');
        for (const t of saved) { t.isActive = false; this.loc.set(t.id, t); }
    }

    cleanup() {
        for (const id of this.loc.keys())  this.stopLocal(id);
        for (const uid of this.pub.keys()) this.stopPublic(uid);
    }
}

const tm = new TunnelManager();
tm.loadMeta();

// ══════════════════════════════════════════════════════════════════════════
//  API ROUTES
// ══════════════════════════════════════════════════════════════════════════

app.get('/api/health', (_, res) => res.json({ status: 'ok', uptime: process.uptime(), version: '3.0' }));

// AUTH
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    const users = await DB.read('users');
    const user  = users.find(u => u.username === username);
    if (!user || !(await bcrypt.compare(password, user.password)))
        return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ userId: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, username: user.username } });
});

app.get('/api/auth/verify', auth, (req, res) => res.json({ valid: true, user: req.user }));

// STATS
app.get('/api/stats', auth, async (req, res) => {
    const [files, fwds] = await Promise.all([DB.read('files'), DB.read('forwards')]);
    const uf = files.filter(f => f.userId === req.user.userId);
    res.json({
        files: uf.length,
        forwards: fwds.filter(f => f.userId === req.user.userId).length,
        localhostTunnels: tm.getUserLocals(req.user.userId).length,
        tunnelActive: !!tm.getPublic(req.user.userId),
        storageUsed: uf.reduce((a, f) => a + (f.size || 0), 0)
    });
});

// PUBLIC TUNNEL
app.post('/api/tunnel/start', auth, async (req, res) => {
    const { port, provider } = req.body;
    if (!port || port < 1 || port > 65535) return res.status(400).json({ error: 'Invalid port' });
    try {
        const url = await tm.startPublic(req.user.userId, parseInt(port), provider || 'localtunnel');
        res.json({ success: true, url, port });
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/tunnel/stop', auth, async (req, res) => {
    await tm.stopPublic(req.user.userId);
    res.json({ success: true });
});

app.get('/api/tunnel/status', auth, (req, res) => {
    const t = tm.getPublic(req.user.userId);
    t ? res.json({ active: true, url: t.url, port: t.port, provider: t.provider })
      : res.json({ active: false });
});

// LOCALHOST TUNNELS
app.post('/api/localhost-tunnels', auth, async (req, res) => {
    const { port, provider } = req.body;
    if (!port || port < 1 || port > 65535) return res.status(400).json({ error: 'Invalid port' });
    if (!['localtunnel','ngrok','cloudflare'].includes(provider)) return res.status(400).json({ error: 'Invalid provider' });
    try { res.json(await tm.createLocal(req.user.userId, req.body)); }
    catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/localhost-tunnels', auth, (req, res) => {
    res.json(tm.getUserLocals(req.user.userId).map(t => tm.clean(t)));
});

app.post('/api/localhost-tunnels/:id/stop', auth, async (req, res) => {
    const t = tm.getLocal(req.params.id);
    if (!t || t.userId !== req.user.userId) return res.status(404).json({ error: 'Not found' });
    await tm.stopLocal(req.params.id);
    res.json({ success: true });
});

app.post('/api/localhost-tunnels/:id/start', auth, async (req, res) => {
    const t = tm.getLocal(req.params.id);
    if (!t || t.userId !== req.user.userId) return res.status(404).json({ error: 'Not found' });
    try {
        await tm.stopLocal(req.params.id);
        res.json(await tm.createLocal(req.user.userId, { port: t.port, provider: t.provider, name: t.name, subdomain: t.subdomain, region: t.region, protocol: t.protocol, requireAuth: t.requireAuth }));
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/localhost-tunnels/:id/restart', auth, async (req, res) => {
    const t = tm.getLocal(req.params.id);
    if (!t || t.userId !== req.user.userId) return res.status(404).json({ error: 'Not found' });
    try {
        await tm.stopLocal(req.params.id);
        res.json(await tm.createLocal(req.user.userId, { port: t.port, provider: t.provider, name: t.name, subdomain: t.subdomain, region: t.region, protocol: t.protocol, requireAuth: t.requireAuth }));
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/localhost-tunnels/:id', auth, async (req, res) => {
    const t = tm.getLocal(req.params.id);
    if (!t || t.userId !== req.user.userId) return res.status(404).json({ error: 'Not found' });
    await tm.deleteLocal(req.params.id);
    res.json({ success: true });
});

// PORT FORWARDING
app.post('/api/forwards', auth, async (req, res) => {
    const { port, name, path: customPath, requireAuth } = req.body;
    if (!port) return res.status(400).json({ error: 'Port required' });
    const fwds = await DB.read('forwards');
    const id   = customPath || uuidv4().slice(0, 8);
    if (fwds.some(f => f.id === id)) return res.status(409).json({ error: 'Path taken' });
    const fwd  = { id, port: parseInt(port), name: name || `Port ${port}`, userId: req.user.userId, requireAuth: !!requireAuth, url: `${req.protocol}://${req.get('host')}/fwd/${id}`, createdAt: new Date().toISOString(), accessCount: 0 };
    fwds.push(fwd);
    await DB.write('forwards', fwds);
    res.json({ success: true, forward: fwd });
});

app.get('/api/forwards', auth, async (req, res) => {
    const fwds = await DB.read('forwards');
    res.json(fwds.filter(f => f.userId === req.user.userId));
});

app.delete('/api/forwards/:id', auth, async (req, res) => {
    let fwds = await DB.read('forwards');
    const i  = fwds.findIndex(f => f.id === req.params.id && f.userId === req.user.userId);
    if (i < 0) return res.status(404).json({ error: 'Not found' });
    fwds.splice(i, 1);
    await DB.write('forwards', fwds);
    res.json({ success: true });
});

app.use('/fwd/:id', async (req, res) => {
    const fwds = await DB.read('forwards');
    const fwd  = fwds.find(f => f.id === req.params.id);
    if (!fwd) return res.status(404).send('Forward not found');
    if (fwd.requireAuth) {
        const t = req.query.token || (req.headers.authorization || '').replace('Bearer ', '');
        if (!t) return res.status(401).send('Add ?token=YOUR_JWT to access');
        try { jwt.verify(t, JWT_SECRET); } catch { return res.status(403).send('Invalid token'); }
    }
    fwd.accessCount = (fwd.accessCount || 0) + 1;
    await DB.write('forwards', fwds);
    const http     = require('http');
    const fwdPath  = req.url.replace(`/fwd/${fwd.id}`, '') || '/';
    const pr       = http.request({ hostname: 'localhost', port: fwd.port, path: fwdPath, method: req.method, headers: { ...req.headers, host: `localhost:${fwd.port}` } }, r => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
    pr.on('error', () => res.status(502).send(`Service on port ${fwd.port} is not running`));
    req.pipe(pr);
});

// FILES (Cloudinary)
app.post('/api/files/upload', auth, upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file' });
    try {
        const result = await cloudinary.uploader.upload(req.file.path, {
            resource_type: 'auto',
            folder: `aruns-server/${req.user.userId}`,
            public_id: uuidv4()
        });
        await fs.unlink(req.file.path).catch(() => {});
        const record = { id: uuidv4(), originalName: req.file.originalname, size: req.file.size, mimetype: req.file.mimetype, cloudinaryId: result.public_id, cloudinaryUrl: result.secure_url, userId: req.user.userId, uploadedAt: new Date().toISOString() };
        const files  = await DB.read('files');
        files.push(record);
        await DB.write('files', files);
        res.json({ success: true, file: { id: record.id, name: record.originalName, size: record.size, url: record.cloudinaryUrl } });
    } catch (e) {
        await fs.unlink(req.file.path).catch(() => {});
        res.status(500).json({ error: 'Upload failed: ' + e.message });
    }
});

app.get('/api/files', auth, async (req, res) => {
    const files = await DB.read('files');
    res.json(files.filter(f => f.userId === req.user.userId).map(f => ({ id: f.id, name: f.originalName, size: f.size, type: f.mimetype, url: f.cloudinaryUrl, uploadedAt: f.uploadedAt })));
});

app.delete('/api/files/:id', auth, async (req, res) => {
    let files = await DB.read('files');
    const f   = files.find(f => f.id === req.params.id && f.userId === req.user.userId);
    if (!f) return res.status(404).json({ error: 'Not found' });
    try { await cloudinary.uploader.destroy(f.cloudinaryId, { resource_type: 'raw' }); } catch {}
    await DB.write('files', files.filter(x => x.id !== req.params.id));
    res.json({ success: true });
});

// ERRORS
app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: 'File too large (max 100MB)' });
    console.error(err);
    res.status(500).json({ error: err.message });
});

// START
const server = app.listen(PORT, () => {
    console.log(`
╔═══════════════════════════════════════════╗
║        ARUN'S SERVER v3.0 — RAILWAY       ║
╠═══════════════════════════════════════════╣
║  http://localhost:${String(PORT).padEnd(24)}║
║  Login: ${ADMIN_USER.padEnd(10)} / ${ADMIN_PASS.padEnd(16)}║
╚═══════════════════════════════════════════╝
`);
});

process.on('SIGTERM', () => { tm.cleanup(); server.close(() => process.exit(0)); });
process.on('SIGINT',  () => { tm.cleanup(); server.close(() => process.exit(0)); });
